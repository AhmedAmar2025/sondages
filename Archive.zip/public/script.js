// ===============================
// Chargement des infos générales
// ===============================
fetch('/infos')
  .then(response => response.json())
  .then(data => {
    const text = `Nombre de candidats : ${data.totalCandidats} | Nombre de votants : ${data.totalVotes}`;
    document.getElementById('marquee-content').textContent = text;
  })
  .catch(error => {
    console.error("Erreur de fetch :", error);
    document.getElementById('marquee-content').textContent = "Erreur de chargement des données.";
  });

// ===============================
// Défilement automatique horizontal des cartes candidats
// ===============================
const candidatsContainer = document.querySelector('.candidats');
setInterval(() => {
  candidatsContainer.scrollBy({
    left: 300,
    behavior: 'smooth'
  });
}, 3000);

// ===============================
// Fonction de vote par secteur (avec progression)
// ===============================
function voterSecteur(secteurId, vote) {
  fetch(`/vote/${secteurId}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ vote })
  })
    .then(response => response.json())
    .then(data => {
      const bar = document.getElementById('progression-' + secteurId);
      bar.style.width = data.progression + '%';
      bar.textContent = data.progression + '%';
    })
    .catch(err => {
      console.error('Erreur lors du vote :', err);
      alert('Erreur lors de l’envoi du vote.');
    });
}

// ===============================
// Ajout d'écouteurs aux formulaires de vote secteur
// ===============================
document.addEventListener("DOMContentLoaded", function () {
  const voteForms = document.querySelectorAll('.vote-buttons form');
  voteForms.forEach((form) => {
    form.addEventListener('submit', function (event) {
      event.preventDefault();
      const secteurId = form.getAttribute('action').split('/').pop();
      const voteValue = form.querySelector('button[type="submit"]:focus').value;
      voterSecteur(secteurId, voteValue);
    });
  });
});

// ===============================
// Fonction voter() pour candidats (incrémentation simple)
// ===============================
function voter(id) {
  const voteCount = document.getElementById(`vote-count-${id}`);
  const message = document.getElementById(`message-${id}`);

  // Envoi de la requête POST pour enregistrer le vote
  fetch(`/vote/${id}`, {
    method: 'POST',
  })
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        // Met à jour dynamiquement le nombre de votes affiché
        if (voteCount) {
          voteCount.textContent = data.votes;
        }

        // Affiche le message de confirmation temporairement
        message.style.display = 'block';
        message.textContent = '✅   لقد تم تصويتكم بنجاح !';

        setTimeout(() => {
          message.style.display = 'none';
        }, 2000);
      }
    })
    .catch(err => {
      console.error('Erreur lors du vote:', err);
    });
}

// ===============================
// Vérifier l'existence d'une image de candidat
// ===============================
function checkImageExists(imageUrl, callback) {
  const img = new Image();
  img.onload = () => callback(true);
  img.onerror = () => callback(false);
  img.src = imageUrl;
}

// ===============================
// Afficher la bonne image du candidat (ou défaut)
// ===============================
function displayImage(candidat) {
  const imagePath = `/images/${candidat.photo}`;
  const imageElement = document.querySelector(`#photo-candidat-${candidat.id}`);
  checkImageExists(imagePath, function (exists) {
    imageElement.src = exists ? imagePath : '/images/default.jpg';
  });
}

// ===============================
// Chargement dynamique des candidats (si besoin)
// ===============================
function loadCandidats() {
  fetch('/votes')
    .then(response => response.json())
    .then(candidats => {
      const candidatsDiv = document.getElementById('candidats');
      candidatsDiv.innerHTML = '';

      candidats.forEach(candidat => {
        const div = document.createElement('div');
        div.className = 'candidat';
        div.innerHTML = `
          <h3>${candidat.nom} (${candidat.parti})</h3>
          <img src="img/${candidat.photo}" alt="${candidat.nom}" />
          <p>Votes: <span id="votes-${candidat.id}">${candidat.votes}</span></p>
          <button class="vote-button" data-candidat-id="${candidat.id}">Voter</button>
          <p id="message-${candidat.id}" class="message-success" style="display:none;"></p>
        `;
        candidatsDiv.appendChild(div);
      });
    })
    .catch(error => console.error('Erreur lors du chargement des candidats:', error));
}

// ===============================
// Affichage de la date et heure en temps réel
// ===============================
function afficherDateHeure() {
  const maintenant = new Date();
  const options = {
    weekday: 'long', year: 'numeric', month: 'long',
    day: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit'
  };
  document.getElementById('date-heure').innerHTML = maintenant.toLocaleDateString('fr-FR', options);
}
setInterval(afficherDateHeure, 1000);
afficherDateHeure();

// ===============================
// Duplication des slides pour effet défilement infini
// ===============================
const sliderTrack = document.querySelector('.slider-track');
if (sliderTrack && window.innerWidth > 768 && !sliderTrack.classList.contains('already-duplicated')) {
  const originalItems = [...sliderTrack.children];
  for (let i = 0; i < 2; i++) {
    originalItems.forEach(item => {
      const clone = item.cloneNode(true);
      clone.classList.add('duplicated');
      sliderTrack.appendChild(clone);
    });
  }
  sliderTrack.classList.add('already-duplicated');
}

// ===============================
// Message confirmation de vote (si vote déjà effectué)
// ===============================
window.addEventListener('load', () => {
  const message = document.querySelector('.message-confirmation');
  const voteEffectué = sessionStorage.getItem('voteEffectué');

  if (voteEffectué) {
    message.innerText = "Votre vote a été pris en compte !";
    message.style.display = 'block';
    setTimeout(() => message.style.display = 'none', 3000);
  }

  // Activation du vote pour chaque bouton (sauvegarde session)
  document.querySelectorAll('.vote-button').forEach(button => {
    button.addEventListener('click', (event) => {
      const candidatId = event.target.getAttribute('data-candidat-id');
      voterCandidat(candidatId);
    });
  });
});

//=======================================
//vote sur les secteurs
//================================
document.querySelectorAll('form').forEach(form => {
  form.addEventListener('submit', function(event) {
      event.preventDefault(); // Empêcher le rechargement de la page

      const secteurId = form.action.split('/').pop(); // Extraire l'ID du secteur à partir de l'URL

      // Récupérer le bouton radio sélectionné
      const vote = form.querySelector('input[name="vote"]:checked'); 

      // Vérifier si un vote a été sélectionné
      if (!vote) {
          alert('Veuillez choisir un vote (oui ou non)');
          return; // Arrêter le traitement si aucun vote n'est sélectionné
      }

      // Récupérer la valeur du vote ("oui" ou "non")
      const voteValue = vote.value;

      // Vérifier que la valeur du vote est correcte
      if (voteValue !== 'oui' && voteValue !== 'non') {
          alert('Vote invalide');
          return; // Si le vote est incorrect, arrêter l'envoi
      }

      // Envoi de la requête fetch pour enregistrer le vote
      fetch(`/vote/${secteurId}`, {
          method: 'POST',
          headers: {
              'Content-Type': 'application/json',
          },
          body: JSON.stringify({ vote: voteValue })
      })
      .then(response => response.json())
      .then(data => {
          if (data.success) {
              alert('Vote enregistré avec succès !');
              afficherSmiley(secteurId, vote);
              // Mettre à jour la page ou afficher un message de confirmation
              // Par exemple, mettre à jour les votes sur la page sans recharger
              document.getElementById("message-" + secteurId).style.display = "block";
          }
      })
      .catch(error => {
          console.error('Erreur lors du vote:', error);
      });
  });
});




document.addEventListener("DOMContentLoaded", () => {
  const buttons = document.querySelectorAll(".vote-btn");

  buttons.forEach((button) => {
    button.addEventListener("click", () => {
      const secteurId = button.dataset.secteur;
      const vote = button.dataset.vote;
      const userId = 1; // Remplace par l’ID dynamique si nécessaire

      fetch("/voter", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ secteurId, userId, vote }),
      })
        .then((res) => res.json())
        .then((data) => {
          if (data.success) {
            // Mettre à jour les barres dynamiquement
            const secteur = document.querySelector(`button[data-secteur='${secteurId}']`).closest(".secteur");
            secteur.querySelector("p:nth-of-type(1)").innerText = `${data.total} votant(s)`;
            secteur.querySelector("p:nth-of-type(2)").innerText = `Oui : ${data.oui}`;
            secteur.querySelector("p:nth-of-type(3)").innerText = `Non : ${data.non}`;
            secteur.querySelector(".oui").style.width = `${data.pourcentageOui}%`;
            secteur.querySelector(".non").style.width = `${data.pourcentageNon}%`;

            // Afficher le message
            secteur.querySelector(`#message-${secteurId}`).style.display = "block";
          } else {
            alert(data.message || "Une erreur est survenue.");
          }
        });
    });
  });
});


document.querySelectorAll('.vote-btn').forEach(button => {
  button.addEventListener('click', function () {
    const secteurId = this.dataset.secteur;
    const vote = this.dataset.vote;
    const userId = 1; // Id utilisateur, tu peux rendre ça dynamique si tu veux

    fetch('/voter', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ secteurId, vote, userId })
    })
    .then(res => res.json())
    .then(data => {
      const messageContainer = document.getElementById('feedback-' + secteurId);
      if (data.success) {
        // Afficher le smiley selon le vote
        if (vote === 'oui') {
          messageContainer.innerHTML = '😊 Merci pour votre vote positif !';
        } else {
          messageContainer.innerHTML = '😞 Merci pour votre retour négatif.';
        }
        messageContainer.style.display = 'block';

        // Optionnel : recharger après 2 secondes pour voir la progression mise à jour
        setTimeout(() => location.reload(), 2000);
      } else if (data.message) {
        messageContainer.innerHTML = '⚠️ ' + data.message;
        messageContainer.style.display = 'block';
      }
    });
  });
});



function afficherSmiley(secteurId, vote) {
  const container = document.getElementById(`smiley-${secteurId}`);
  const smileys = container.querySelectorAll('.smiley');
  
  // Cache tous les smileys d'abord
  smileys.forEach(s => s.style.display = 'none');
  smileys.forEach(s => s.classList.remove('show'));

  // Affiche le bon smiley selon le vote
  const smiley = vote === 'oui' ? smileys[0] : smileys[1];
  smiley.style.display = 'inline-block';

  // Animation déclenchée légèrement après l’affichage
  setTimeout(() => {
    smiley.classList.add('show');
  }, 10);
}





function updateSecteurUI(secteurId, ouiVotes, nonVotes) {
  let totalVotesSecteurs = ouiVotes + nonVotes;

  let ouiPourcentage = (ouiVotes / totalVotesSecteurs) * 100;
  let nonPourcentage = (nonVotes / totalVotesSecteurs) * 100;

  // Mise à jour du texte
  document.querySelector(`#ouiVotes-${secteurId}`).textContent = `${ouiVotes} votes`;
  document.querySelector(`#nonVotes-${secteurId}`).textContent = `${nonVotes} votes`;

  // Mise à jour des barres de progression
  document.querySelector(`#progress-oui-${secteurId}`).style.width = `${ouiPourcentage}%`;
  document.querySelector(`#progress-non-${secteurId}`).style.width = `${nonPourcentage}%`;
}


/*fin vote secteurs*/




// Tableau des pubs
const pubs = [
  { image: "/images/pub1.gif", link: "https://pub1.com" },
  { image: "/images/pub2.gif", link: "https://pub2.com" },
  { image: "/images/pub3.gif", link: "https://pub3.com" }
];

// Index actuel
let index = 0;

// Changement automatique toutes les 5 secondes
setInterval(() => {
  index = (index + 1) % pubs.length;
  document.getElementById('pub-image').src = pubs[index].image;
  document.getElementById('pub-link').href = pubs[index].link;
}, 5000);



//controle vote avec IP







