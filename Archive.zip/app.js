
const express = require('express');
const bodyParser = require('body-parser');
const session = require('express-session');
const path = require('path');
const app = express();
const port = 3000;
const mysql = require('mysql');
app.use('/images', express.static('public/images'));

// Connexion à la base de données
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'Ahmed1969',
  database: 'sondage'
});

db.connect(err => {
  if (err) throw err;
  console.log('Connexion MySQL réussie');
});



// Middleware pour gérer les données JSON et les formulaires
app.use(express.json());  // Pour les requêtes JSON
app.use(bodyParser.urlencoded({ extended: true }));  // Pour les formulaires URL-encodés

// Middleware pour servir les fichiers statiques
app.use(express.static(path.join(__dirname, 'public')));

// Configuration des sessions
app.use(session({
  secret: 'secret-key',
  resave: false,
  saveUninitialized: true
}));

// Configurer le moteur de templates EJS
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));


// Route d'accueil pour afficher les candidats triés par nombre de votes
app.get('/', (req, res) => {
  const sqlCandidats = 'SELECT * FROM candidats ORDER BY votes DESC';
  const sqlSecteurs = 'SELECT * FROM secteurs';

  // D'abord on récupère les candidats
  db.query(sqlCandidats, (err, candidats) => {
    if (err) throw err;

    const totalVotes = candidats.reduce((sum, c) => sum + c.votes, 0);
    const topCandidat = candidats[0];

    // Ensuite on récupère les secteurs
    db.query(sqlSecteurs, (err, secteurs) => {
      if (err) throw err;

      // On calcule le total des votes sur les secteurs
      const totalVotesSecteurs = secteurs.reduce((sum, s) => sum + s.oui + s.non, 0);

      // Et on rend la page avec toutes les données nécessaires
      res.render('index', {
        candidats,
        totalVotes,
        topCandidat,
        secteurs,              // nécessaire si tu veux afficher les secteurs
        totalVotesSecteurs     // pour le bloc إجمالي المصوتين
      });
    });
  });
});




// Route pour voter pour un candidat
app.post('/vote/:id', (req, res) => {
  const id = req.params.id;
  const sql = 'UPDATE candidats SET votes = votes + 1 WHERE id = ?';
  db.query(sql, [id], (err, result) => {
    if (err) return res.json({ success: false });

    // Récupérer le nombre de votes après l'incrémentation
    const sql2 = 'SELECT votes FROM candidats WHERE id = ?';
    db.query(sql2, [id], (err2, result2) => {
      if (err2) return res.json({ success: false });

      const votes = result2[0].votes;  // Nombre de votes après incrémentation
      res.json({ success: true, votes });
    });
  });
});

// Route pour récupérer infos globales sur le nombre des candidats
app.get('/infos', (req, res) => {
  const sqlCandidats = 'SELECT COUNT(*) AS totalCandidats FROM candidats';
  const sqlVotes = 'SELECT SUM(votes) AS totalVotes FROM candidats';

  db.query(sqlCandidats, (err, candidatsResult) => {
      if (err) return res.status(500).json({ error: err });
      
      db.query(sqlVotes, (err, votesResult) => {
          if (err) return res.status(500).json({ error: err });

          res.json({
              totalCandidats: candidatsResult[0].totalCandidats,
              totalVotes: votesResult[0].totalVotes || 0
          });
      });
  });
});


/* les secteurs*/
const logos = {
  "Éducation": "education.png",
  "Santé": "sante.png",
  "Sécurité": "securite.png",
  "Justice": "justice.png",
  "Somelec": "somelec.png",
  "SNDE": "snde.png",
  "Somagaz": "somagaz.png",
  "TAAZOUR": "taazour.png"
};
app.get('/index', (req, res) => {
  // Récupération des secteurs
  db.query('SELECT * FROM secteurs', (err, secteurs) => {
    if (err) {
      console.error("Erreur récupération secteurs :", err);
      return res.status(500).send('Erreur récupération secteurs');
    }

    // Récupération des candidats
    db.query('SELECT * FROM candidats ORDER BY votes DESC', (err, candidats) => {
      if (err) {
        console.error("Erreur récupération candidats :", err);
        return res.status(500).send('Erreur récupération candidats');
      }

      // Sécurité : si candidats est vide ou contient un élément undefined
      const topCandidat = Array.isArray(candidats) && candidats.length > 0 ? candidats[0] : null;

      // Calcul du total des votes en toute sécurité
      const totalVotes = Array.isArray(candidats)
        ? candidats.reduce((total, c) => total + (c?.votes || 0), 0)
        : 0;

      // Affichage dans la console pour debug
     // console.log("Candidats récupérés :", candidats);

      res.render('index', {
        secteurs: secteurs,
        candidats: candidats,
        topCandidat: topCandidat,
        totalVotes: totalVotes
       
      });
    });
  });
});

const vote = async (req, res) => {
  try {
    const secteurId = parseInt(req.params.id);
    const vote = req.body.vote;
    const userId = req.session.userId || 1;

    if (!secteurId || !vote) {
      return res.status(400).send('Paramètres manquants ou invalides');
    }

    // Vérifier si l'utilisateur a déjà voté
    const checkVoteSql = 'SELECT * FROM votes_utilisateur WHERE user_id = ? AND secteur_id = ?';
    const [checkVoteResult] = await db.promise().query(checkVoteSql, [userId, secteurId]);

    if (checkVoteResult.length > 0) {
      return res.status(400).send('Vous avez déjà voté pour ce secteur');
    }

    // Insertion du vote
    const insertVoteSql = 'INSERT INTO votes_utilisateur (user_id, secteur_id, vote) VALUES (?, ?, ?)';
    await db.promise().query(insertVoteSql, [userId, secteurId, vote]);

    // Mise à jour des votes dans la table secteur
    const column = vote === 'oui' ? 'oui' : 'non';
    const updateSql = `UPDATE secteurs SET ${column} = ${column} + 1 WHERE id = ?`;
    await db.promise().query(updateSql, [secteurId]);

    return res.json({ success: true, message: 'Vote enregistré avec succès' });
  } catch (err) {
    console.error('🔴 Erreur:', err);
    return res.status(500).send('Erreur serveur');
  }
};

app.post("/voter", (req, res) => {
  const { userId, secteurId, vote } = req.body;

  if (!userId || !secteurId || !["oui", "non"].includes(vote)) {
    return res.json({ success: false, message: "Données invalides" });
  }

  // Vérifier si l'utilisateur a déjà voté
  const checkVoteSql = "SELECT * FROM votes_utilisateur WHERE user_id = ? AND secteur_id = ?";
  db.query(checkVoteSql, [userId, secteurId], (err, results) => {
    if (err) return res.json({ success: false, message: "Erreur de requête" });

    if (results.length > 0) {
      return res.json({ success: false, message: "Vous avez déjà voté pour ce secteur." });
    }

    // Insérer le vote utilisateur
    const insertVoteSql = "INSERT INTO votes_utilisateur (user_id, secteur_id, vote) VALUES (?, ?, ?)";
    db.query(insertVoteSql, [userId, secteurId, vote], (err2) => {
      if (err2) return res.json({ success: false });

      // Incrémenter le compteur dans secteurs
      const updateVoteSql = `UPDATE secteurs SET ${vote} = ${vote} + 1 WHERE id = ?`;
      db.query(updateVoteSql, [secteurId], (err3) => {
        if (err3) return res.json({ success: false });

        // Renvoyer les nouveaux résultats
        db.query("SELECT oui, non FROM secteurs WHERE id = ?", [secteurId], (err4, rows) => {
          if (err4 || rows.length === 0) return res.json({ success: false });

          const { oui, non } = rows[0];
          const total = oui + non;
          const pourcentageOui = ((oui / total) * 100).toFixed(2);
          const pourcentageNon = ((non / total) * 100).toFixed(2);

          res.json({ success: true, oui, non, total, pourcentageOui, pourcentageNon });
        });
      });
    });
  });
});

app.get('/secteurs', (req, res) => {
  const query = 'SELECT * FROM secteurs';

  db.query(query, (err, secteurs) => {
    if (err) {
      console.error('Erreur lors de la récupération des secteurs :', err);
      return res.status(500).send('Erreur serveur');
    }

    const totalVotesSecteurs = secteurs.reduce((acc, secteur) => acc + secteur.oui + secteur.non, 0);
    res.render('secteurs', { secteurs, totalVotesSecteurs }); // ✅
  });
});





//fin de vote par secteurs*/


app.use(express.static('public'));
// Route pour récupérer les résultats des votes (facultatif pour AJAX)
app.get('/votes', (req, res) => {
  db.query('SELECT id, votes FROM candidats', (err, results) => {
    if (err) return res.status(500).json([]);
    res.json(results);
  });
});

const multer = require('multer');


// Configuration pour multer
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'public/images'); // ou 'public/images' si tu préfères
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + '-' + file.originalname);
  }
});

const upload = multer({ storage: storage });


//------------------------------------------------------
// section d'admin pour ajouter et suprimer des candidats
//---------------------------------------------------------
app.set('view engine', 'ejs');
app.use(express.static('public'));  // Pour servir les images depuis le dossier 
app.set('views', path.join(__dirname, 'views'));  // Assure-toi que le chemin est correct

// Route POST pour ajouter un candidat
// Cette route permet d'ajouter un candidat dans la base de données.
app.post('/ajouter', upload.single('photo'), (req, res) => {
  // Extraction des informations envoyées dans le corps de la requête
  const { nom, parti, fonction } = req.body;

  // Vérification si une photo a été téléchargée
  // Si une photo est téléchargée, on prend son nom (sinon on attribue 'null')
  const photo = req.file ? req.file.filename : null;

  // Requête SQL pour insérer un nouveau candidat dans la base de données
  const sql = "INSERT INTO candidats (nom, parti, fonction, photo, votes) VALUES (?, ?, ?, ?, 0)";
  
  // Exécution de la requête SQL
  db.query(sql, [nom, parti, fonction, photo], (err, result) => {
    // Gestion des erreurs et des succès
    if (err) {
      // Si une erreur se produit, on enregistre un message d'erreur dans la session
      req.session.message = { type: 'error', content: "Erreur lors de l'ajout du candidat." };
    } else {
      // Si tout se passe bien, on enregistre un message de succès dans la session
      req.session.message = { type: 'success', content: "Candidat ajouté avec succès." };
    }
    // Redirection vers la page d'ajout de candidat
    res.redirect('/ajouter');
  });
});




app.get('/index', (req, res) => {
  // Récupérer les bannières depuis la base de données
  connection.query('SELECT * FROM bannieres', (err, rows) => {
      if (err) {
          console.log(err);
          res.status(500).send('Error retrieving banners');
          return;
      }
      // Envoi des bannières à la page EJS
      res.render('index', { bannieres: rows });
  });
});


// Route pour afficher la page 'ajouter'
// Route GET pour afficher la page 'ajouter'
app.get('/ajouter', (req, res) => {
  // Requêtes pour récupérer les candidats, secteurs et bannières
  const sqlCandidats = 'SELECT * FROM candidats';
  const sqlSecteurs = 'SELECT * FROM secteurs';
  const sqlBannieres = 'SELECT * FROM bannieres';

  db.query(sqlCandidats, (err, candidats) => {
    if (err) throw err;

    db.query(sqlSecteurs, (err, secteurs) => {
      if (err) throw err;

      db.query(sqlBannieres, (err, bannieres) => {
        if (err) throw err;

        res.render('ajouter', {
          candidats: candidats,
          secteurs: secteurs,
          bannieres: bannieres,
          message: req.session.message || null
        });

        req.session.message = null; // Réinitialiser le message après l'affichage
      });
    });
  });
});

// Route POST pour ajouter un candidat
app.post('/ajouter', upload.single('photo'), (req, res) => {
  const { nom, parti, fonction } = req.body;
  const photo = req.file ? req.file.filename : null;

  const sql = "INSERT INTO candidats (nom, parti, fonction, photo, votes) VALUES (?, ?, ?, ?, 0)";

  db.query(sql, [nom, parti, fonction, photo], (err, result) => {
    if (err) {
      req.session.message = { type: 'error', content: "Erreur lors de l'ajout du candidat." };
    } else {
      req.session.message = { type: 'success', content: "Candidat ajouté avec succès." };
    }
    res.redirect('/ajouter');  // Rediriger après avoir ajouté un candidat
  });
});

// Route POST pour supprimer un candidat
app.post('/delete-candidat', (req, res) => {
  const { id } = req.body;
  const sql = 'DELETE FROM candidats WHERE id = ?';

  db.query(sql, [id], (err, result) => {
    if (err) {
      req.session.message = { type: 'error', content: "Erreur lors de la suppression du candidat." };
    } else {
      req.session.message = { type: 'success', content: "Candidat supprimé avec succès." };
    }
    res.redirect('/ajouter');  // Rediriger après suppression
  });
});




//ajouter des secteurs ou suprimer
// Route pour ajouter un secteur
app.post('/ajouter-secteur', upload.single('secteurLogo'), (req, res) => {
  const { nom } = req.body;
  const logo = req.file ? req.file.filename : null;

  const sql = 'INSERT INTO secteurs (nom, secteurLogo) VALUES (?, ?)';
  db.query(sql, [nom, logo], (err, result) => {
    if (err) {
      console.error(err);
      req.session.message = "Erreur lors de l'ajout du secteur.";
    } else {
      req.session.message = 'Secteur ajouté avec succès.';
    }
    res.redirect('/ajouter');
  });
});



// Route pour supprimer un secteur
app.post('/supprimerSecteur', (req, res) => {
  const secteurId = req.body.secteurASupprimer;

  // Supprimer le secteur de la base de données
  const sql = 'DELETE FROM secteurs WHERE id = ?';
  db.query(sql, [secteurId], (err, result) => {
    if (err) throw err;
    res.redirect('/ajouter');
  });
});


// Route pour ajouter une nouvelle bannière

app.post('/ajouter-banniere', upload.single('image'), (req, res) => {
  const { titre, lien } = req.body;
  const image = req.file.filename;

  const sql = 'INSERT INTO bannieres (titre, image, lien) VALUES (?, ?, ?)';
  db.query(sql, [titre, image, lien], (err, result) => {
    if (err) throw err;
    res.redirect('/');
  });
});


// Route pour supprimer une bannière
app.post('/supprimer-banniere', (req, res) => {
  const { id } = req.body;
  const sql = 'DELETE FROM bannieres WHERE id = ?';
  db.query(sql, [id], (err, result) => {
    if (err) throw err;
    res.redirect('/');  // Rediriger vers la page d'accueil après suppression
  });
});



//pour remettre le votye a Zero
app.post('/reset-votes', (req, res) => {
  db.query('UPDATE candidats SET votes = 0', (err, result) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Erreur lors de la réinitialisation des votes');
    }
    res.redirect('/'); // ou autre page
  });
});




app.post('/voter', (req, res) => {
  const ip = req.body.ip_address; // Récupérer l'IP de l'utilisateur
  const candidatId = req.body.candidat_id; // ID du candidat pour lequel l'utilisateur vote
  
  // Vérifier si cette adresse IP a déjà voté pour ce candidat
  const checkQuery = 'SELECT * FROM votes_candidats WHERE ipAddress = ? AND candidat_id = ?';
  db.query(checkQuery, [ip, candidatId], (err, results) => {
    if (err) {
      return res.status(500).json({ message: 'Erreur lors de la vérification du vote' });
    }

    if (results.length > 0) {
      return res.status(400).json({ message: 'Vous avez déjà voté pour ce candidat' });
    }

    // Enregistrer le vote pour le candidat
    const insertQuery = 'INSERT INTO votes_candidats (candidat_id, ipAddress) VALUES (?, ?)';
    db.query(insertQuery, [candidatId, ip], (err, result) => {
      if (err) {
        return res.status(500).json({ message: 'Erreur lors de l\'enregistrement du vote' });
      }

      return res.status(200).json({ message: 'Votre vote a été pris en compte' });
    });
  });
});




//securite admin
app.use(session({
  secret: 'motDePasseSecretUltraFort',
  resave: false,
  saveUninitialized: false,
  cookie: { secure: false } // mettre true si HTTPS
}));

const bcrypt = require('bcrypt');

// utilisateur fictif
const adminUser = {
  username: "admin",
  passwordHash: bcrypt.hashSync("motdepasse1969", 10) // à remplacer par un vrai hash stocké
};

// page de connexion
app.get('/login', (req, res) => {
  res.render('login');
});

// traitement du login
app.post('/login', (req, res) => {
  const { username, password } = req.body;
  if (username === adminUser.username && bcrypt.compareSync(password, adminUser.passwordHash)) {
    req.session.user = username;
    res.redirect('/ajouter');
  } else {
    res.send('Identifiants invalides');
  }
});

// déconnexion
app.get('/logout', (req, res) => {
  req.session.destroy(() => {
    res.redirect('/login');
  });
});


function requireAuth(req, res, next) {
  if (req.session.user === "admin") {
    next();
  } else {
    res.redirect('/login');
  }
}

app.get('/ajouter', requireAuth, (req, res) => {
  res.render('ajouter');
});




// Lancer le serveur
app.listen(port, () => {
  console.log(`Serveur démarré sur http://localhost:${port}`);
});
