
// db.js
const mysql = require('mysql2');

// Créez la connexion avec votre base de données MySQL
const connection = mysql.createConnection({
  host: 'localhost',  // Hôte de votre base de données, généralement 'localhost'
  user: 'root',       // Utilisateur MySQL
  password: 'Ahmed1969',       // Mot de passe MySQL (vide par défaut pour XAMPP/MAMP)
  database: 'sondage' // Nom de votre base de données
});

// Connectez-vous à la base de données
connection.connect((err) => {
  if (err) {
    console.error('Erreur de connexion à la base de données :', err);
    return;
  }
  console.log('Connexion à la base de données réussie !');
});

// Exposez la connexion pour pouvoir l'utiliser dans app.js
module.exports = connection;


