

const mysql = require('mysql2');

// Créez la connexion à la base de données
const connection = mysql.createConnection({
  host: 'localhost',  // Remplacez par l'hôte de votre base de données
  user: 'root',       // Remplacez par le nom d'utilisateur de votre base de données
  password: '',       // Remplacez par le mot de passe de votre base de données
  database: 'sondage' // Remplacez par le nom de votre base de données
});

// Vérifiez si la connexion fonctionne
connection.connect((err) => {
  if (err) {
    console.error('Erreur de connexion à la base de données :', err);
    return;
  }
  console.log('Connexion à la base de données réussie !');
});

module.exports = connection; // Exporte la connexion

