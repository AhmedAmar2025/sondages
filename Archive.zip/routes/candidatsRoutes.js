// candidatsRoutes.js
const express = require('express');
const router = express.Router();
const connection = require('../db');  // Importer la connexion à la base de données



// ...routes ici

module.exports = router;  // تأكد أنك تصدّر الـ router

// Récupérer tous les candidats
router.get('/candidats', (req, res) => {
  connection.query('SELECT * FROM candidats', (err, results) => {
    if (err) {
      console.error('Erreur lors de la récupération des candidats :', err);
      return res.status(500).json({ error: 'Erreur lors de la récupération des candidats' });
    }
    res.json(results);  // Retourner les candidats sous forme de JSON
  });
});
// Ajouter un nouveau candidat (via API)
router.post('/candidats', (req, res) => {
    const { nom, parti } = req.body; // Récupérer les données envoyées par le formulaire
    
    if (!nom || !parti) {
      return res.status(400).json({ error: 'Nom et parti sont nécessaires' });
    }
  
    // Insertion du nouveau candidat dans la base de données
    const query = 'INSERT INTO candidats (nom, parti, votes) VALUES (?, ?, ?)';
    connection.query(query, [nom, parti, 0], (err, result) => {
      if (err) {
        console.error('Erreur lors de l\'ajout du candidat :', err);
        return res.status(500).json({ error: 'Erreur lors de l\'ajout du candidat' });
      }
      res.json({ message: 'Candidat ajouté avec succès', candidateId: result.insertId });
    });
  });
  
  // Enregistrer un vote pour un candidat
  router.post('/vote', (req, res) => {
    const { candidate_id, ipAddress } = req.body;  // Récupérer les données du vote
  
    if (!candidate_id || !ipAddress) {
      return res.status(400).json({ error: 'Données manquantes' });
    }
  
    // Enregistrement du vote dans la table "votes"
    connection.query(
      'INSERT INTO votes (candidate_id, ipAddress) VALUES (?, ?)',
      [candidate_id, ipAddress],
      (err, result) => {
        if (err) {
          console.error('Erreur lors de l\'enregistrement du vote :', err);
          return res.status(500).json({ error: 'Erreur lors de l\'enregistrement du vote' });
      }

      // Incrémentation du nombre de votes du candidat
      connection.query(
        'UPDATE candidats SET votes = votes + 1 WHERE id = ?',
        [candidate_id],
        (err) => {
          if (err) {
            console.error('Erreur lors de l\'incrémentation des votes :', err);
            return res.status(500).json({ error: 'Erreur lors de l\'incrémentation des votes' });
          }
          res.json({ message: 'Vote enregistré avec succès' });
        }
      );
    }
  );
})
