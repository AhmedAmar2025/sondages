const path = require('path');
const fs = require('fs');
const db = require('../config/db');
const multer = require('multer');

// Configuration de Multer (à utiliser dans le routeur)
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + '-' + file.originalname);
  }
});
const upload = multer({ storage });
exports.upload = upload;

// Contrôleur principal de la page admin
exports.getAdminPage = async (req, res) => {
  try {
    const [candidats] = await db.query('SELECT * FROM candidats');
    const [secteurs] = await db.query('SELECT * FROM secteurs');
    const [bannieres] = await db.query('SELECT * FROM bannieres');

    res.render('admin', {
      candidats,
      secteurs,
      bannieres
    });
  } catch (err) {
    console.error("Erreur lors du chargement de la page admin :", err);
    res.status(500).send("Erreur serveur");
  }
};

// Réinitialisation des votes des secteurs
exports.resetVotesSecteurs = async (req, res) => {
  try {
    await db.query('UPDATE secteurs SET votes_oui = 0, votes_non = 0');
    res.redirect('/admin');
  } catch (err) {
    console.error("Erreur lors de la réinitialisation des votes des secteurs :", err);
    res.status(500).send("Erreur serveur");
  }
};

// Réinitialisation des votes des candidats
exports.resetVotes = async (req, res) => {
  try {
    await db.query('UPDATE candidats SET votes = 0');
    res.redirect('/admin');
  } catch (err) {
    console.error(err);
    res.status(500).send('Erreur lors de la réinitialisation des votes');
  }
};

// Ajout d’un secteur
exports.addSecteur = async (req, res) => {
  const nom = req.body.nom;
  const logo = req.file ? req.file.filename : null;

  try {
    await db.query('INSERT INTO secteurs (nom, logo) VALUES (?, ?)', [nom, logo]);
    res.redirect('/admin');
  } catch (err) {
    console.error(err);
    res.status(500).send('Erreur lors de l\'ajout du secteur');
  }
};

// Suppression d’un secteur
exports.deleteSecteur = async (req, res) => {
  const id = req.params.id;

  try {
    const [rows] = await db.query('SELECT logo FROM secteurs WHERE id = ?', [id]);

    if (rows.length > 0 && rows[0].logo) {
      const logoPath = path.join('uploads', rows[0].logo);
      if (fs.existsSync(logoPath)) {
        fs.unlinkSync(logoPath);
      }
    }

    await db.query('DELETE FROM secteurs WHERE id = ?', [id]);
    res.redirect('/admin');
  } catch (err) {
    console.error(err);
    res.status(500).send('Erreur lors de la suppression du secteur');
  }
};