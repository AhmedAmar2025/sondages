const path = require('path');
const fs = require('fs');
const db = require('../config/db');

// Ajouter un secteur
exports.addSecteur = async (req, res) => {
  try {
    const { nom, nom_ar } = req.body;
    const logo = req.file ? req.file.filename : null;

    if (!nom || !nom_ar) {
      return res.status(400).send("Tous les champs sont requis.");
    }

    await db.query(
      'INSERT INTO secteurs (nom, nom_ar, logo, votes_oui, votes_non) VALUES (?, ?, ?, 0, 0)',
      [nom, nom_ar, logo]
    );

    res.redirect('/admin');
  } catch (err) {
    console.error("Erreur lors de l’ajout du secteur :", err);
    res.status(500).send("Erreur serveur");
  }
};







