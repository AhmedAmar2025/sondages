
const db = require('../config/db');

exports.vote = async (req, res) => {
  const { id } = req.body;
  try {
    await db.query('UPDATE satisfaction SET votes = votes + 1 WHERE id = ?', [id]);
    res.redirect('/merci'); // à adapter selon ta structure
  } catch (error) {
    console.error('Erreur lors du vote satisfaction:', error);
    res.status(500).send('Erreur serveur');
  }
};





exports.resetVotes = async (req, res) => {
  try {
    await db.query('UPDATE satisfaction SET votes = 0');
    res.redirect('/admin');
  } catch (error) {
    console.error('Erreur remise à zéro satisfaction:', error);
    res.status(500).send('Erreur serveur');
  }
};


exports.getAll = async (req, res) => {
  try {
    const [rows] = await db.query('SELECT * FROM satisfaction');
    res.render('admin', { satisfactionVotes: rows }); // à adapter selon ton rendu
  } catch (error) {
    console.error('Erreur récupération satisfaction:', error);
    res.status(500).send('Erreur serveur');
  }
};
