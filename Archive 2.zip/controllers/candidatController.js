const path = require('path');
const fs = require('fs');
const db = require('../config/db');

// Ajouter un candidat
exports.ajouterCandidat = async (req, res) => {
  try {
    const { nom, parti, fonction } = req.body;
    const photo = req.file ? req.file.filename : null;

    await db.query(
      'INSERT INTO candidats (nom, parti, fonction, photo) VALUES (?, ?, ?, ?)',
      [nom, parti, fonction, photo]
    );

    res.status(200).json({ nom, parti, fonction, photo });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Erreur serveur' });
  }
};

// Ajouter un candidat via formulaire
exports.addCandidat = async (req, res) => {
  try {
    const { nom, secteur_id } = req.body;
    const photo = req.file ? req.file.filename : null;

    await db.query(
      'INSERT INTO candidats (nom, secteur_id, photo) VALUES (?, ?, ?)',
      [nom, secteur_id, photo]
    );

    res.redirect('/admin');
  } catch (error) {
    console.error('Erreur lors de l’ajout du candidat :', error);
    res.status(500).send('Erreur serveur');
  }
};

// Supprimer un candidat
exports.deleteCandidat = async (req, res) => {
  try {
    const { id } = req.params;

    // Supprimer la photo associée au candidat
    const [rows] = await db.query('SELECT photo FROM candidats WHERE id = ?', [id]);
    if (rows.length > 0 && rows[0].photo) {
      const photoPath = path.join(__dirname, '..', 'public', 'uploads', 'candidats', rows[0].photo);
      if (fs.existsSync(photoPath)) fs.unlinkSync(photoPath);
    }

    // Supprimer le candidat de la base de données
    await db.query('DELETE FROM candidats WHERE id = ?', [id]);
    res.redirect('/admin');
  } catch (error) {
    console.error('Erreur lors de la suppression du candidat :', error);
    res.status(500).send('Erreur serveur');
  }
};
// controllers/candidatController.js

// Récupérer les informations du top candidat et l'afficher dans la vue

exports.getTopCandidatPage = async (req, res) => {
  try {
    const [topCandidat] = await db.query(
      `SELECT * FROM candidats ORDER BY votes DESC LIMIT 1`
    );
    const [totalVotesResult] = await db.query(
      `SELECT SUM(votes) AS totalVotes FROM candidats`
    );
    const totalVotes = totalVotesResult[0].totalVotes || 0;

    console.log("Top Candidat:", topCandidat);
    console.log("Total Votes:", totalVotes);

    res.json({ topCandidat: topCandidat[0], totalVotes });
  } catch (error) {
    console.error("Erreur dans getTopCandidat:", error);
    res.status(500).json({ error: "Erreur serveur" });
  }
};


// Rendre la page d'accueil avec les secteurs et autres données
exports.renderAccueil = async (req, res) => {
  try {
    // Récupérer les secteurs
    const [secteurs] = await db.query('SELECT * FROM secteurs');

    // Calculer le pourcentage des votes pour chaque secteur
    secteurs.forEach(secteur => {
      const totalVotes = secteur.votes_oui + secteur.votes_non;
      secteur.pourcentage = totalVotes > 0 ? (secteur.votes_oui / totalVotes) * 100 : 0;
    });

    // Récupérer les autres données (bannières, candidats, etc.)
    const [bannieres] = await db.query('SELECT * FROM banniere');
    const [candidats] = await db.query('SELECT * FROM candidats');
    const [topCandidat] = await db.query('SELECT * FROM candidats ORDER BY votes DESC LIMIT 1');
    const [satisfactionStats] = await db.query('SELECT reponse, COUNT(*) AS total FROM satisfaction GROUP BY reponse');
    const [totalVotesSecteurs] = await db.query('SELECT SUM(votes_oui + votes_non) AS total FROM secteurs');
    const totalSuffragesGlobaux = totalVotesSecteurs[0].total || 0;

    // Envoyer les données à la vue
    res.render('index', {
      bannieres,
      secteurs,
      candidats,
      topCandidat,
      satisfactionStats,
      totalVotes: totalVotesSecteurs[0].total,
      totalSuffragesGlobaux
    });

  } catch (error) {
    console.error("Erreur lors du rendu de la page d'accueil : ", error);
    res.status(500).send("Une erreur est survenue");
  }
};
