
// controllers/authController.js


const db = require('../config/db');
const bcrypt = require('bcrypt');

exports.login = async (req, res) => {
  const { username, password } = req.body;

  try {
    const [rows] = await db.query("SELECT * FROM admins WHERE username = ?", [username]);

    if (rows.length === 0) {
      return res.render('login', { error: "Nom d'utilisateur ou mot de passe incorrect." });
    }

    const admin = rows[0];
    const isMatch = await bcrypt.compare(password, admin.password);

    if (!isMatch) {
      return res.render('login', { error: "Nom d'utilisateur ou mot de passe incorrect." });
    }

    req.session.admin = { id: admin.id, username: admin.username };
    res.redirect('/admin');

  } catch (err) {
    console.error("Erreur lors de la connexion :", err);
    res.status(500).send("Erreur serveur");
  }
};





// Affiche la page de connexion
exports.showLogin = (req, res) => {
  res.render('login', { error: null });
};



// Déconnexion
exports.logout = (req, res) => {
  req.session.destroy(() => {
    res.redirect('/');
  });
};

// Middleware de protection de route
exports.ensureAuthenticated = (req, res, next) => {
  if (req.session && req.session.admin) {
    next();
  } else {
    res.redirect('/');
  }
};