const express = require('express');
const router = express.Router();
const requireAdminAuth = require('../middlewares/requireAdminAuth');
const { upload } = require('../controllers/adminController');

const adminController = require('../controllers/adminController');
const candidatController = require('../controllers/candidatController');
const banniereController = require('../controllers/banniereController');

// ✅ Route protégée pour afficher la page admin
router.get('/', requireAdminAuth, adminController.getAdminPage);

// ✅ Réinitialisation des votes
router.post('/reset-votes-secteurs', adminController.resetVotesSecteurs);
router.post('/reset-votes', adminController.resetVotes);

// ✅ Secteurs (ajout / suppression)
router.post('/secteurs', upload.single('logo'), adminController.addSecteur);
router.post('/secteurs/delete/:id', adminController.deleteSecteur);

// ✅ Candidats (ajout / suppression)
router.post('/ajouter-candidat', upload.single('photo'), candidatController.ajouterCandidat);
router.post('/candidats/delete/:id', candidatController.deleteCandidat);

// ✅ Bannières (ajout / suppression)
router.post('/admin/ajouter-banniere', upload.single('image'), banniereController.ajouterBanniere);
router.post('/bannieres/delete/:id', banniereController.deleteBanniere);

module.exports = router;