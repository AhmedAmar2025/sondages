const express = require('express');
const router = express.Router();
const db = require('../config/db');
const upload = require('../config/multer');  // Importer la configuration Multer
const candidatController = require('../controllers/candidatController');

// Route pour afficher le top candidat (page avec vue)
router.get('/top-candidat', candidatController.getTopCandidatPage);



// Route pour récupérer le top candidat en format JSON (API)
router.get('/api/top-candidat', candidatController.getTopCandidatPage);

// Ajouter un candidat
router.post('/admin/ajouter-candidat', upload.single('photo'), async (req, res) => {
    const { nom, fonction, description } = req.body;
    const photo = req.file ? req.file.filename : null;
  
    if (!nom || !fonction || !photo) {
      return res.status(400).send("Tous les champs requis ne sont pas fournis.");
    }
  
    try {
      await db.query(
        'INSERT INTO candidats (nom, fonction, photo, description, votes) VALUES (?, ?, ?, ?, 0)',
        [nom, fonction, photo, description]
      );
      res.redirect('/admin');
    } catch (err) {
      console.error("Erreur ajout candidat:", err);
      res.status(500).send("Erreur serveur");
    }
  });

// Route pour supprimer un candidat
router.post('/admin/supprimer-candidat', async (req, res) => {
    const candidatId = req.body.candidatId;  // Récupère l'ID du candidat à supprimer
    if (!candidatId) {
      return res.status(400).send("ID du candidat manquant");
    }
  
    try {
      // Suppression du candidat dans la base de données
      await db.query('DELETE FROM candidats WHERE id = ?', [candidatId]);
      res.redirect('/admin');  // Redirige vers la page admin après suppression
    } catch (err) {
      console.error("Erreur suppression candidat:", err);
      res.status(500).send("Erreur serveur");
    }
  });

module.exports = router;