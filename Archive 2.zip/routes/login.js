
const express = require('express');
const router = express.Router();
const db = require('../config/db');

// Affiche le formulaire de login
router.get('/login', (req, res) => {
  res.render('login', { error: null });
});

// Gère la connexion admin
router.post('/login', async (req, res) => {
  const { username, password } = req.body;

  try {
    const [rows] = await db.query(
      'SELECT * FROM admins WHERE username = ? AND password = ?',
      [username, password]
    );

    if (rows.length > 0) {
      req.session.admin = true;
      res.redirect('/admin');
    } else {
      res.render('login', { error: 'Identifiants invalides' });
    }
  } catch (err) {
    console.error('Erreur de connexion admin :', err);
    res.render('login', { error: 'Erreur serveur' });
  }
});

module.exports = router;