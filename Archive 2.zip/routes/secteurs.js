const express = require('express');
const router = express.Router();
const db = require('../config/db');
const upload = require('../config/multer');
const path = require('path');
const fs = require('fs');

// Ajouter un secteur
router.post('/admin/secteurs/add', upload.single('logo'), async (req, res) => {
  const { nom, nom_ar } = req.body;
  const logo = req.file ? req.file.filename : null;

  if (!nom || !nom_ar || !logo) {
    return res.status(400).send("Tous les champs sont requis.");
  }

  try {
    await db.query(
      'INSERT INTO secteurs (nom, nom_ar, logo, votes_oui, votes_non) VALUES (?, ?, ?, 0, 0)',
      [nom, nom_ar, logo]
    );
    res.redirect('/admin');
  } catch (err) {
    console.error("Erreur ajout secteur:", err);
    res.status(500).send("Erreur serveur");
  }
});


// Exemple de route pour réinitialiser les secteurs
router.post('/reset-secteurs', async (req, res) => {
  try {
    // Logique pour réinitialiser les secteurs
    await db.query('UPDATE secteurs SET statut = "inactif"'); // Exemple de mise à jour

    // Redirection ou message de succès
    res.redirect('/admin');  // Exemple de redirection vers la page admin
  } catch (err) {
    console.error('Erreur lors de la réinitialisation des secteurs:', err);
    res.status(500).send('Erreur serveur');
  }
});

module.exports = router;



// Supprimer un secteur
router.post('/admin/secteurs/delete/:id', async (req, res) => {
  const secteurId = req.params.id;

  try {
    const [rows] = await db.query('SELECT logo FROM secteurs WHERE id = ?', [secteurId]);
    if (rows.length === 0) {
      return res.status(404).send("Secteur introuvable");
    }

    const logo = rows[0].logo;
    const logoPath = path.join(__dirname, '../uploads', logo);
    if (fs.existsSync(logoPath)) {
      fs.unlinkSync(logoPath); // Supprime le fichier
    }

    await db.query('DELETE FROM secteurs WHERE id = ?', [secteurId]);
    res.redirect('/admin');
  } catch (err) {
    console.error("Erreur suppression secteur:", err);
    res.status(500).send("Erreur serveur");
  }
});

module.exports = router;
