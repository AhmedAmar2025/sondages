// routes/satisfaction.js
const express = require('express');
const router = express.Router();
const db = require('../config/db');

// Route POST pour enregistrer un vote de satisfaction
router.post('/vote-satisfaction', async (req, res) => {
  const { reponse } = req.body;

  if (!reponse) {
    return res.status(400).json({ message: 'Réponse manquante' });
  }

  try {
    await db.query('INSERT INTO satisfaction (reponse) VALUES (?)', [reponse]);

    const [results] = await db.query('SELECT reponse, COUNT(*) as count FROM satisfaction GROUP BY reponse');

    const stats = {
      oui: results.find(r => r.reponse === 'oui')?.count || 0,
      non: results.find(r => r.reponse === 'non')?.count || 0,
    };

    const [rows] = await db.query(`
      SELECT
        SUM(reponse = 'oui') AS oui,
        SUM(reponse = 'non') AS non
      FROM satisfaction
    `);

    res.json({ message: 'Vote enregistré avec succès', stats });
  } catch (err) {
    console.error('Erreur lors de l\'enregistrement du vote :', err);
    res.status(500).json({ message: 'Erreur serveur' });
  }
});

// Pour réinitialiser
router.post('/reset-satisfaction', async (req, res) => {
  try {
    await db.query('DELETE FROM satisfaction');
    res.redirect('/admin');
  } catch (err) {
    console.error("Erreur lors de la réinitialisation des satisfactions:", err);
    res.status(500).send("Erreur serveur");
  }
});

module.exports = router;