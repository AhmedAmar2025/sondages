
// routes/publicRoutes.js
const express = require('express');
const router = express.Router();

// Exemple de route publique
router.get('/', (req, res) => {
  res.send('Page publique');
});

module.exports = router;