
const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const db = require('./db');

module.exports = function(passport) {
  passport.use(new LocalStrategy(
    async (username, password, done) => {
      try {
        const [rows] = await db.query(
          'SELECT * FROM administrateurs WHERE username = ? AND password = ?',
          [username, password]
        );
        if (rows.length > 0) {
          return done(null, rows[0]);
        } else {
          return done(null, false, { message: 'Identifiants incorrects' });
        }
      } catch (err) {
        return done(err);
      }
    }
  ));

  passport.serializeUser((user, done) => {
    done(null, user.id);
  });

  passport.deserializeUser(async (id, done) => {
    try {
      const [rows] = await db.query('SELECT * FROM administrateurs WHERE id = ?', [id]);
      done(null, rows[0]);
    } catch (err) {
      done(err);
    }
  });
};


module.exports = passport;