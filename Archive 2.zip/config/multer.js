const path = require('path');
const multer = require('multer');

// Configuration du stockage des fichiers
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    // Spécifier le dossier où les fichiers seront stockés
    cb(null, path.join(__dirname, '..', 'public', 'uploads'));  // `__dirname` est utilisé pour obtenir le répertoire actuel
  },
  filename: (req, file, cb) => {
    // Générer un nom unique pour chaque fichier
    cb(null, Date.now() + '-' + file.originalname);  // Vous pouvez personnaliser le nom du fichier ici
  }
});

// Créer une instance de Multer
const upload = multer({ storage: storage });

module.exports = upload;  // Exporter le middleware Multer







