
// =========================================
// 2. Affichage de la date et l'heure en temps réel
// =========================================
function afficherDateHeure() {
  const maintenant = new Date();
  const options = {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  };
  const dateHeure = document.getElementById("date-heure");
  if (dateHeure) {
    dateHeure.innerHTML = maintenant.toLocaleDateString("fr-FR", options);
  }
}
setInterval(afficherDateHeure, 1000);
afficherDateHeure();


// =========================================
// 7. Fonction pour voter pour un candidat
// =========================================
function voterC(candidatId) {
  fetch('/voter-candidat', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ candidatId: candidatId })
  })
  .then(response => response.json())
  .then(data => {
    if (data.success) {
      // Mettre à jour nombre de votes du candidat
      document.getElementById(`vote-count-${candidatId}`).textContent = data.updatedVotes;

      // Mettre à jour % affiché
      const pourcentage = data.pourcentage.toFixed(1);
      const percentElement = document.querySelector(`#vote-count-${candidatId}`).nextElementSibling;
      if (percentElement) {
        percentElement.innerHTML = `<strong></strong> ${pourcentage} %`;
      }

      // Animation de la barre
      const barre = document.getElementById(`progress-bar-${candidatId}`);
      if (barre) {
        barre.style.transition = 'width 1.2s ease';
        barre.style.backgroundColor = 'limegreen'; // couleur verte
        barre.style.width = '100%'; // remplir à 100%

        setTimeout(() => {
          barre.style.transition = 'width 1.2s ease';
          barre.style.width = `${pourcentage}%`; // revenir au vrai pourcentage
          barre.innerText = `${pourcentage}%`;
        }, 1200);
      }

      // Afficher message de succès
      const message = document.getElementById(`message-${candidatId}`);
      message.innerText = "Merci pour votre vote ! 🙏";
      message.style.display = 'block';
      setTimeout(() => {
        message.style.display = 'none';
      }, 3000);

      // Mise à jour du top candidat
      if (data.topCandidat) {
        document.querySelector('.top-candidat').innerHTML = `
          <div class="candidat top">
            <h3>الشخصية السياسية الأكثر شعبية في موريتانيا</h3>
            <h3>La personnalité politique la plus populaire en Mauritanie</h3> 
            <hr style="border: none; height: 1px; background-color: #ffffff; margin: 10px 0;">
            <img src="//uploads/${data.topCandidat.photo}" alt="${data.topCandidat.nom}" class="photo-candidat-top" />
            <h3>${data.topCandidat.nom}</h3></br>
            <p><strong>Pourcentage :</strong> ${data.topPourcentage.toFixed(1)} %</p>
            <p><strong>Nombre total des votants :</strong> ${data.totalVotes}</p>
            <p class="top-candidat-description">${data.topCandidat.description || ''}</p>
          </div>
        `;
      }

    } else {
      alert("Erreur lors du vote.");
    }
  })
  .catch(error => {
    console.error('Erreur réseau :', error);
  });
}


// =========================================
// 2. Fonction pour afficher un message de confirmation temporairement
// =========================================
function showConfirmationMessage(element, message, duration = 2000) {
  if (!element) return;
  element.innerText = message;
  element.style.display = 'block';
  setTimeout(() => {
    element.style.display = 'none';
  }, duration);
}

// =========================================
// 3. Fonction pour voter pour un secteur
// =========================================
async function voterSecteur(secteurId, reponse) {
  try {
    const response = await fetch('/voter-secteur', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ secteurId, reponse })
    });

    if (!response.ok) throw new Error('Erreur serveur');
    const data = await response.json();

    if (data.success) {
      // 1. Mise à jour des votes
      document.getElementById(`oui-${secteurId}`).textContent = data.updatedVotesOui;
      document.getElementById(`non-${secteurId}`).textContent = data.updatedVotesNon;
      document.getElementById('total-votants').textContent = data.totalVotants;

      // 2. Mise à jour du pourcentage
      const satisfactionFixe = data.satisfactionFixe.toFixed(2);
      document.getElementById(`pourcentage-${secteurId}`).textContent = satisfactionFixe + '%';

      // 3. Animation de la barre
      const progressBar = document.getElementById(`progression-${secteurId}`);
      progressBar.style.transition = 'width 0.5s ease-in-out';
      progressBar.style.width = satisfactionFixe + '%';
      progressBar.textContent = satisfactionFixe + '%';

      // 4. Message de feedback
      const feedback = document.getElementById(`feedback-${secteurId}`);
      if (feedback) {
        feedback.style.display = 'block';
        feedback.innerText = "Merci pour votre vote ! 🙏";
        setTimeout(() => {
          feedback.style.display = 'none';
        }, 3000);
      }

    } else {
      alert('Erreur lors du vote.');
    }

  } catch (error) {
    console.error('Erreur lors de l\'envoi du vote :', error);
    alert('Erreur serveur.');
  }
}



//=====================================
// barre progressive des candidats
//======================================
function animerBarre(candidatId) {
  const barre = document.getElementById(`progress-bar-${candidatId}`);
  if (!barre) return;

  const pourcentageReel = parseFloat(barre.getAttribute('data-percent')) || 0;

  // Étape 1 : on simule un remplissage à 100%
  barre.style.width = '100%';
  barre.innerText = '100%';

  // Étape 2 : après 1.5s, on revient au pourcentage réel
  setTimeout(() => {
    barre.style.width = `${pourcentageReel}%`;
    barre.innerText = `${pourcentageReel.toFixed(1)}%`;
  }, 1500);
}



// =========================================
// 5. Chargement dynamique des candidats
// =========================================
async function loadCandidats() {
  try {
    const response = await fetch("/votes");
    if (!response.ok) throw new Error("Erreur de chargement !");
    const candidats = await response.json();

    const candidatsDiv = document.getElementById("candidats");
    if (candidatsDiv) {
      candidatsDiv.innerHTML = "";
      candidats.forEach(candidat => {
        const div = document.createElement("div");
        div.className = "candidat";
        div.innerHTML = `
          <h3>${candidat.nom} (${candidat.parti})</h3>
          <img src="/uploads/${candidat.photo}" alt="${candidat.nom}" id="photo-candidat-${candidat.id}" />
          <p>Votes: <span id="vote-count-${candidat.id}">${candidat.votes}</span> <span></span></p>
          <div class="progress-bar-container">
            <div class="progress-bar" style="width:0%"></div>
          </div>
          <button class="vote-button" data-candidat-id="${candidat.id}">Voter</button>
          <p id="message-${candidat.id}" class="message-success" style="display:none;"></p>
        `;
        candidatsDiv.appendChild(div);

        // Vérification image
        displayImage(candidat);
      });

      // Ajouter écouteurs de vote
      document.querySelectorAll(".vote-button").forEach(button => {
        button.addEventListener("click", () => {
          const candidatId = button.getAttribute("data-candidat-id");
          voterCandidat(candidatId);
        });
      });
    }
  } catch (error) {
    console.error("Erreur lors du chargement des candidats :", error);
  }
}

// =========================================
// 6. Vérifier si une image existe
// =========================================
function checkImageExists(url, callback) {
  const img = new Image();
  img.onload = () => callback(true);
  img.onerror = () => callback(false);
  img.src = url;
}

// =========================================
// 7. Afficher image candidat ou image par défaut
// =========================================
function displayImage(candidat) {
  const imagePath = `/uploads/${candidat.photo}`;
  const imageElement = document.querySelector(`#photo-candidat-${candidat.id}`);
  checkImageExists(imagePath, (exists) => {
    if (imageElement) {
      imageElement.src = exists ? imagePath : "/uploads/default.jpg";
    }
  });
}

//===============================
//incrementation vote secteur
//============================
  document.addEventListener('DOMContentLoaded', function () {
    const buttons = document.querySelectorAll('.vote-btn');
  
    buttons.forEach(button => {
      button.addEventListener('click', function () {
        const secteurId = this.getAttribute('data-secteur');
        const reponse = this.getAttribute('data-reponse');
  
        fetch('/voter-secteur', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ secteurId, reponse })
        })
        .then(response => response.json())
        .then(data => {
          if (data.success) {
            document.getElementById(`oui-${secteurId}`).textContent = data.updatedVotesOui;
            document.getElementById(`non-${secteurId}`).textContent = data.updatedVotesNon;
            document.getElementById('total-votants').textContent = data.totalVotants;
  
            const satisfactionFixe = data.satisfactionFixe.toFixed(2);
            document.getElementById(`pourcentage-${secteurId}`).textContent = satisfactionFixe;
  
            const progressBar = document.getElementById(`progression-${secteurId}`);
            progressBar.style.width = satisfactionFixe + '%';
            progressBar.textContent = satisfactionFixe + '%';
  
            const feedback = document.getElementById(`feedback-${secteurId}`);
            feedback.style.display = 'block';
            feedback.innerText = "Merci pour votre vote ! 🙏";
            setTimeout(() => feedback.style.display = 'none', 3000);
          } else {
            alert("Erreur serveur.");
          }
        })
        .catch(error => console.error('Erreur réseau :', error));
      });
    });
  });
  
  //=================================
  //mouvement des barr rouge ou vert
  //===================================
  document.addEventListener('DOMContentLoaded', function () {
    // Sélectionner toutes les barres de progression
    const bars = document.querySelectorAll('.progress-bar');
  
    // Initialisation des barres de progression
    bars.forEach(bar => {
      const pourcentage = bar.getAttribute('data-pourcentage');
      bar.style.width = pourcentage + '%';
    });
  
    // Gestion des événements de clic sur les boutons de vote
    document.querySelectorAll('.vote-btn').forEach(btn => {
      btn.addEventListener('click', function(event) {
        event.preventDefault(); // Empêche le comportement par défaut (soumission du formulaire)
  
        const btn = event.target;
        const secteurId = btn.dataset.secteur;
        const reponse = btn.dataset.reponse;
  
        // Appel de la fonction de gestion du vote
        handleVote(secteurId, reponse);
      });
    });
  
    function handleVote(id, reponse) {
      const bar = document.getElementById('progression-' + id);
      const form = document.getElementById('voteForm-' + id);
      const realPourcentage = bar.getAttribute('data-pourcentage');
  
      // Ajouter la couleur (rouge ou verte) en fonction de la réponse
      if (reponse === 'non') {
        bar.classList.add('red'); 
        bar.classList.remove('green');
      } else {
        bar.classList.add('green');
        bar.classList.remove('red');
      }
  
      // Animation de la barre de progression
      bar.style.transition = 'width 1s ease';
      bar.style.width = '100%';
  
      // Bloquer les autres boutons pendant l'animation
      form.querySelectorAll('button').forEach(button => button.disabled = true);
  
      // Revenir à la largeur du pourcentage réel après l'animation
      setTimeout(() => {
        bar.style.width = realPourcentage + '%';
  
        // Soumettre le formulaire via AJAX pour éviter un rechargement de la page
        submitVoteForm(form);
      }, 1000);  // Délai de 1 seconde pour l'animation
    }
  
    // Fonction pour soumettre le formulaire via AJAX
    function submitVoteForm(form) {
      const formData = new FormData(form);
  
      // Effectuer la requête AJAX pour soumettre les données sans recharger la page
      fetch(form.action, {
        method: 'POST',
        body: formData,
      })
      .then(response => response.json())
      .then(data => {
        // Gérer la réponse du serveur, mettre à jour l'UI si nécessaire
        console.log(data);
      })
      .catch(error => {
        console.error('Erreur lors de l\'envoi du vote:', error);
      });
    }
  });
  
  //===================================
  //message de remerciment d'avoir voter oui ou non
  //=====================================
  
  document.querySelectorAll('.vote-btn').forEach(button => {
      button.addEventListener('click', function () {
          const secteurId = this.getAttribute('data-secteur');
          const reponse = this.getAttribute('data-reponse');
          const progressBar = document.getElementById('progression-' + secteurId);
          const voteForm = document.getElementById('voteForm-' + secteurId);
  
          if (!progressBar || !voteForm) return;
  
          // Animation de la barre
          progressBar.style.transition = 'width 0.8s ease, background-color 0.8s ease';
          progressBar.style.backgroundColor = (reponse === 'oui') ? 'green' : 'red';
          progressBar.style.width = '100%';
  
          // Désactiver les boutons
          voteForm.querySelectorAll('.vote-btn').forEach(btn => btn.disabled = true);
  
          // Retirer l'ancien message s'il existe
          let oldMessage = document.querySelector(`#message-${secteurId}`);
          if (oldMessage) oldMessage.remove();
  
          // Créer un nouveau message
          const message = document.createElement('div');
          message.id = `message-${secteurId}`;
          message.textContent = `Merci d'avoir voté ${reponse === 'oui' ? 'Oui' : 'Non'} !`;
          message.style.marginTop = '10px';
          message.style.padding = '8px';
          message.style.backgroundColor = '#ffffff'; // vert clair
          message.style.color = '#155724'; // texte vert foncé
          message.style.border = '1px solid #c3e6cb';
          message.style.borderRadius = '4px';
  
          // Ajouter le message sous le formulaire
          voteForm.parentNode.insertBefore(message, voteForm.nextSibling);
  
          // Revenir à l'état normal de la barre après 2 secondes
          setTimeout(() => {
              progressBar.style.backgroundColor = '#080df4'; // bleu normal
              progressBar.style.width = progressBar.getAttribute('data-pourcentage') + '%';
          }, 2000);
      });
  });
   


 
 
  document.querySelectorAll('.satisfaction-button').forEach(button => {
    button.addEventListener('click', async (e) => {
      e.preventDefault();
      const reponse = button.value;

      try {
        const response = await fetch('/vote-satisfaction', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ reponse })
        });

        const data = await response.json();
        if (data.reponse === 'oui') {
          const current = parseInt(document.getElementById('result-oui').textContent) || 0;
          document.getElementById('result-oui').textContent = current + 1;
        } else {
          const current = parseInt(document.getElementById('result-non').textContent) || 0;
          document.getElementById('result-non').textContent = current + 1;
        }
        alert("Merci pour votre réponse !");
      } catch (err) {
        alert('Erreur lors du vote');
        console.error(err);
      }
    });
  });



  async function voterSatisfaction(reponse) {
    try {
      const response = await fetch('/vote-satisfaction', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reponse })
      });
  
      if (!response.ok) throw new Error('Erreur serveur');
  
      const data = await response.json();
  
      if (data.stats) {
        const spanOui = document.getElementById('result-oui');
        const spanNon = document.getElementById('result-non');
  
        // Mise à jour des chiffres
        spanOui.textContent = data.stats.oui || 0;
        spanNon.textContent = data.stats.non || 0;
  
        // Animation du chiffre
        const span = reponse === 'oui' ? spanOui : spanNon;
        span.classList.add('animate');
        setTimeout(() => span.classList.remove('animate'), 300);
  
        // Afficher le message
        const feedback = document.getElementById('vote-feedback');
        feedback.style.display = 'block';
        feedback.style.animation = 'fadeInOut 3s ease-in-out';
        setTimeout(() => {
          feedback.style.display = 'none';
        }, 3000);
      }
  
    } catch (error) {
      console.error('Erreur :', error);
      alert('Une erreur est survenue.');
    }
  }
  







  async function refreshTopCandidat() {
    try {
      const response = await fetch('/api/top-candidat');
      const data = await response.json();

      const container = document.getElementById('top-candidat-container');

      if (data && data.topCandidat) {
        const pourcentage = data.totalVotes > 0
          ? ((data.topCandidat.votes / data.totalVotes) * 100).toFixed(1)
          : '0';

        container.innerHTML = `
          <div class="top-candidat">
            <div class="candidat top">
              <h3>الشخصية السياسية الأكثر شعبية في موريتانيا</h3>
              <h3>La personnalité politique la plus populaire en Mauritanie</h3> 
              <div id="date-heure"></div>
              <hr style="border: none; height: 1px; background-color: #ffffff; margin: 10px 0;">
              <img src="/uploads/${data.topCandidat.photo}" alt="${data.topCandidat.nom}" class="photo-candidat-top" />
              <h3>${data.topCandidat.nom}</h3>
              <p><strong>Pourcentage :</strong> ${pourcentage} %</p>
              <p><strong>Nombre total des votants :</strong> ${data.totalVotes}</p>
              <p class="top-candidat-description">${data.topCandidat.description || ''}</p>
            </div>
          </div>
        `;
      }
    } catch (err) {
      console.error('Erreur lors de la mise à jour du top candidat :', err);
    }
  }

  // Appel au chargement + mise à jour toutes les 10 secondes
  window.addEventListener('DOMContentLoaded', () => {
    refreshTopCandidat();
    setInterval(refreshTopCandidat, 10000);
  });
