const express = require("express");
const session = require("express-session");
const bodyParser = require("body-parser");
const path = require("path");
const geoip = require("geoip-lite");
const passport = require('./config/passport');
const dotenv = require('dotenv');
dotenv.config();
require('dotenv').config({ path: './secret.env' }); // Si tu utilises secret.env

const loginRoutes = require('./routes/login');
const candidatController = require('./controllers/candidatController'); // Déplacer l'importation ici
const app = express();
const port = 3000;

// Middleware d'upload
const upload = require('./middlewares/upload');
const requireAdminAuth = require('./middlewares/requireAdminAuth');

// Configuration du moteur de vues
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

// Middleware pour parser les requêtes
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Gestion des fichiers statiques
app.use(express.static('public'));

// Sert uniquement les images uploadées depuis /uploads/ dans EJS
app.use('/uploads', express.static(path.join(__dirname, 'public/uploads')));
app.use('/uploads', express.static(path.join(__dirname, 'public', 'uploads')));
app.use('/public', express.static(path.join(__dirname, 'public')));
app.use(express.static('public')); // Pour CSS/JS
app.use('/uploads', express.static('uploads')); // Pour les images


// Middleware pour les fichiers statiques (à garder)


app.get('/test-photo', (req, res) => {
  res.send(`
    <h1>Test d'affichage photo</h1>
    <h2>Image uploadée :</h2>
    <img src="/uploads/biram.jpg" style="width: 300px; border: 2px solid red;">
    <h2>Image par défaut :</h2>
    <img src="/images/default-profile.jpg" style="width: 300px; border: 2px solid blue;">
  `);
});


// Dans votre route API (app.js)/+app.get('/api/top-candidat', async (req, res) => {
  /*const [candidat] = await db.query('SELECT * FROM candidats ORDER BY votes DESC LIMIT 1');
  
  // Ajoutez ce debug
  console.log('Photo path from DB:', candidat[0].photo);
  
  // Forcez le chemin absolu si nécessaire
  candidat[0].photo = candidat[0].photo ? candidat[0].photo.trim() : null;
  
  res.json(candidat[0]);
});*/


// Routes
const satisfactionRoutes = require('./routes/satisfaction');
const secteursRoutes = require("./routes/secteurs");
const banniereRoutes = require("./routes/bannieres");
const adminRoutes = require("./routes/admin");
const candidatsRoutes = require('./routes/candidats');
const publicRoutes = require('./routes/publicRoutes');

// Utilisation des routes
app.use('/login', loginRoutes);  // Login route
app.use('/admin', adminRoutes);  // Admin routes
app.use('/secteurs', secteursRoutes);  // Secteurs routes
app.use('/candidats', candidatsRoutes);  // Candidats routes
app.use('/banniere', banniereRoutes);  // Bannières routes
app.use('/', satisfactionRoutes);  // Satisfaction routes
app.use('/public', publicRoutes);  // Fichiers publics

// Route pour la page d'accueil
app.get('/', candidatController.renderAccueil);

// Route pour afficher la page top-candidat
app.get('/top-candidat', candidatController.getTopCandidatPage);

// Configuration des sessions
app.use(session({
  secret: "votre_clé_secrète_ici", // à changer pour un projet réel
  resave: false,
  saveUninitialized: false,
  cookie: {
    maxAge: 3600000, // 1 heure
    httpOnly: true,
    sameSite: "lax", // ou 'strict'
    secure: false // à true uniquement si HTTPS
  }
}));

// Initialisation de Passport
app.use(passport.initialize());
app.use(passport.session());

// Logger (affiche les requêtes entrantes)
app.use((req, res, next) => {
  console.log(`➡️ ${req.method} ${req.url}`);
  console.log("Headers:", req.headers["content-type"]);
  console.log("Body:", req.body);
  next();
});

// Connexion à la base de données
const db = require('./config/db');
(async () => {
  try {
    const connection = await db.getConnection();
    console.log('✅ Connecté à la base de données avec l\'ID ' + connection.threadId);
    connection.release();
  } catch (err) {
    console.error('❌ Erreur de connexion à la base de données :', err);
  }
});





// Page de login
app.get("/login", (req, res) => {
  res.render("login", { error: null });
});

app.post("/login", async (req, res) => {
  const { username, password } = req.body;
  try {
    const [rows] = await db.query(
      "SELECT * FROM administrateurs WHERE username = ? AND password = ?",
      [username, password]
    );

    if (rows.length > 0) {
      const admin = rows[0];
      req.session.admin = { id: admin.id, username: admin.username };
      console.log("✅ Admin connecté :", req.session.admin);
      res.redirect("/admin");
    } else {
      res.render("login", { error: "Identifiants incorrects" });
    }
  } catch (error) {
    console.error("Erreur lors de la connexion :", error);
    res.render("login", { error: "Erreur serveur" });
  }
});




// Routes publiques pour l'ajout et suppression des secteurs
app.post('/admin/ajouter-secteur', upload.single('logo'), async (req, res) => {
  try {
    const { nom, nom_ar } = req.body;
    const logo = req.file ? req.file.filename : null;

    if (!nom || !nom_ar) {
      return res.status(400).send("Tous les champs sont requis.");
    }

    // Ajout SQL direct
    await db.query(
      'INSERT INTO secteurs (nom, nom_ar, logo, votes_oui, votes_non) VALUES (?, ?, ?, 0, 0)',
      [nom, nom_ar, logo]
    );

    res.redirect('/admin');
  } catch (error) {
    console.error("Erreur lors de l'ajout du secteur :", error);
    res.status(500).send("Erreur serveur");
  }
});



// Route pour supprimer un secteur
app.get('/admin/supprimer-secteur/:id', async (req, res) => {
  try {
    const secteurId = req.params.id;

    // Supprimer le secteur de la base de données
    const secteur = await db.Secteur.findByPk(secteurId);

    // Vérifier si le secteur existe
    if (secteur) {
      // Supprimer le logo du système de fichiers
      const fs = require('fs');
      const filePath = path.join(__dirname, 'uploads', secteur.logo);
      if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath); // Supprimer le fichier du logo
      }

      // Supprimer le secteur de la base de données
      await secteur.destroy();

      res.redirect('/admin'); // Rediriger après suppression
    } else {
      res.status(404).send('Secteur introuvable');
    }
  } catch (error) {
    console.error('Erreur lors de la suppression du secteur :', error);
    res.status(500).send('Erreur serveur');
  }
});



// Routes protégées (admin)
app.use("/admin", requireAdminAuth, adminRoutes);

// Routes publiques
app.use("/", candidatsRoutes);
app.use("/", secteursRoutes);
app.use("/", banniereRoutes);

// Page d'accueil
app.get("/", async (req, res) => {
  try {
    const [candidats] = await db.query(
      "SELECT * FROM candidats ORDER BY votes DESC"
    );
    const [secteurs] = await db.query("SELECT * FROM secteurs");

    const [stats] = await db.query(`
      SELECT 
        SUM(reponse = 'oui') AS oui,
        SUM(reponse = 'non') AS non
      FROM satisfaction
    `);
   
    const [voteCount] = await db.query('SELECT SUM(votes) as totalVotes FROM candidats');
    const totalVotes = candidats.reduce((sum, c) => sum + c.votes, 0);
    const topCandidat = candidats[0];
    const totalSuffragesGlobaux = secteurs.reduce(
      (sum, s) => sum + s.votes_oui + s.votes_non,
      0
    );
    secteurs.forEach((secteur) => {
      secteur.pourcentage =
        totalSuffragesGlobaux > 0
          ? (secteur.votes_oui * 100) / totalSuffragesGlobaux
          : 0;
    });
    res.render("index", {
      candidats,
      totalVotes,
      topCandidat,
      secteurs,
      totalVotesSecteurs: totalSuffragesGlobaux,
      totalSuffragesGlobaux,
      satisfactionStats: stats[0], // ← à envoyer à la vue
    });
  } catch (err) {
    console.error("Erreur dans la route / :", err);
    res.status(500).send("Erreur serveur");
  }
});

//=================================
// POST /vote-secteur
//==================================
app.post('/vote-secteur', async (req, res) => {
  const secteurId = req.body.secteur_id;
  try {
    // Incrémenter le vote
    await db.query('UPDATE secteurs SET votes = votes + 1 WHERE id = ?', [secteurId]);
    // Récupérer le nouveau total
    const [rows] = await db.query('SELECT votes FROM secteurs WHERE id = ?', [secteurId]);
    res.json({ success: true, totalVotes: rows[0].votes });
  } catch (err) {
    console.error(err);
    res.json({ success: false, message: "Erreur serveur." });
  }
});




//========================================
// Route pour voter pour un candidat
//===========================================

app.post('/voter-candidat', async (req, res) => {
  const { candidatId } = req.body;

  try {
    // Incrémenter les votes du candidat
    await db.query('UPDATE candidats SET votes = votes + 1 WHERE id = ?', [candidatId]);
    // Récupérer les nouveaux votes pour le candidat
    const [candidatRows] = await db.query('SELECT * FROM candidats WHERE id = ?', [candidatId]);
    const candidat = candidatRows[0];
    // Récupérer tous les candidats pour recalculer le top candidat
    const [allCandidats] = await db.query('SELECT * FROM candidats ORDER BY votes DESC');
    const totalVotes = allCandidats.reduce((sum, c) => sum + c.votes, 0);
    const topCandidat = allCandidats[0];
    const topPourcentage = totalVotes > 0 ? (topCandidat.votes / totalVotes) * 100 : 0;
    res.json({
      success: true,
      updatedVotes: candidat.votes,
      pourcentage: totalVotes > 0 ? (candidat.votes / totalVotes) * 100 : 0,
      totalVotes,
      topCandidat,
      topPourcentage
    });

  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Erreur serveur' });
  }
});

// ============================================
// ROUTE 1 : Voter pour un secteur (recommandée)
// POST /voter-secteur
// ============================================

app.post('/voter-secteur', async (req, res) => {
  const { secteurId, reponse } = req.body;

  try {
    console.log(`📥 Requête reçue pour le secteur : ${secteurId} avec la réponse : ${reponse}`);

    // Vérification que la réponse est valide
    if (!['oui', 'non'].includes(reponse)) {
      return res.status(400).json({ success: false, message: 'Réponse invalide.' });
    }

    // Déterminer le champ à incrémenter
    const field = reponse === 'oui' ? 'votes_oui' : 'votes_non';

    // Construire la requête SQL
    const sql = `UPDATE secteurs SET ${field} = ${field} + 1 WHERE id = ?`;

    // 1. Incrémenter Oui ou Non dans la table secteurs
    const [updateVote] = await db.query(sql, [secteurId]);

    // Vérification si l'update a bien modifié une ligne
    if (updateVote.affectedRows === 0) {
      return res.status(404).json({ success: false, message: 'Secteur non trouvé.' });
    }
   
    // 2. Récupérer les nouveaux votes_oui et votes_non pour ce secteur
    const [secteurRows] = await db.query('SELECT votes_oui, votes_non FROM secteurs WHERE id = ?', [secteurId]);
    const updatedVotesOui = secteurRows[0].votes_oui;
    const updatedVotesNon = secteurRows[0].votes_non;

    console.log(`✅ Votes OUI : ${updatedVotesOui}, Votes NON : ${updatedVotesNon}`);

    // 3. Incrémenter aussi le nombre total de votants
    await db.query('UPDATE global_stats SET total_votants = total_votants + 1 WHERE id = 1');

    // 4. Récupérer le nouveau total des votants
    const [globalRows] = await db.query('SELECT total_votants FROM global_stats WHERE id = 1');
    const totalVotants = globalRows[0].total_votants;

    console.log(`🌍 Total votants : ${totalVotants}`);

    // 5. Calculer la satisfaction (pourcentage des "oui")
    const satisfactionFixe = (updatedVotesOui * 100) / totalVotants;

    // 6. Réponse au client
    res.json({
      success: true,
      updatedVotesOui,
      updatedVotesNon,
      totalVotants,
      satisfactionFixe: satisfactionFixe.toFixed(2)
    });

  } catch (err) {
    console.error('❌ Erreur lors de la mise à jour :', err);
    res.status(500).json({ success: false, message: 'Erreur serveur' });
  }
});





// Page d’accueil avec stats
app.get('/', async (req, res) => {
  try {
    const [results] = await db.query('SELECT reponse, COUNT(*) as count FROM satisfaction GROUP BY reponse');

    const satisfactionStats = {
      oui: results.find(r => r.reponse === 'oui')?.count || 0,
      non: results.find(r => r.reponse === 'non')?.count || 0,
    };

    res.render('satisfaction', { satisfactionStats });
  } catch (err) {
    console.error(err);
    res.status(500).send('Erreur serveur');
  }
});















//=======================================
//verification de vote par ip
//======================================
app.post("/voter", async (req, res) => {
  const { secteurId, reponse } = req.body;

  let ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress;

  // Simulation pour localhost
  if (ip === "::1" || ip === "127.0.0.1") {
    console.log("IP locale détectée :", ip);
    userCountry = 'MR';
  } else {
    try {
      const response = await fetch(`https://ipapi.co/${ip}/json/`);
      const data = await response.json();
      var userCountry = data.country;
    } catch (error) {
      console.error("Erreur géolocalisation :", error);
      return res.status(500).json({ success: false, message: "Erreur géolocalisation" });
    }
  }

  if (userCountry !== 'MR') {
    return res.status(403).json({ success: false, message: "Vote interdit depuis votre pays." });
  }

  try {
    // Mise à jour des votes
    const colonne = (reponse === "oui") ? "votes_oui" : "votes_non";
    await db.promise().query(`UPDATE secteurs SET ${colonne} = ${colonne} + 1 WHERE id = ?`, [secteurId]);

    // Récupération du secteur mis à jour
    const [secteurs] = await db.promise().query(`SELECT votes_oui, votes_non FROM secteurs WHERE id = ?`, [secteurId]);
    const secteur = secteurs[0];

    const votesOui = secteur.votes_oui;
    const votesNon = secteur.votes_non;
    const totalVotesSecteur = votesOui + votesNon;
    const pourcentageOui = (votesOui / totalVotesSecteur) * 100;

    // Récupération du total global
    const [totalRows] = await db.promise().query(`SELECT SUM(votes_oui + votes_non) AS totalGlobal FROM secteurs`);
    const totalGlobal = totalRows[0].totalGlobal || 0;

    res.json({
      success: true,
      votesOui,
      votesNon,
      pourcentageOui,
      totalGlobal
    });
  } catch (error) {
    console.error("Erreur traitement vote :", error);
    res.status(500).json({ success: false, message: "Erreur serveur" });
  }
});



//================================
// Route pour récupérer infos globales sur le nombre des candidats
//====================================
app.get("/infos", (req, res) => {
  const sqlCandidats = "SELECT COUNT(*) AS totalCandidats FROM candidats";
  const sqlVotes = "SELECT SUM(votes) AS totalVotes FROM candidats";

  db.query(sqlCandidats, (err, candidatsResult) => {
    if (err) return res.status(500).json({ error: err });

    db.query(sqlVotes, (err, votesResult) => {
      if (err) return res.status(500).json({ error: err });

      res.json({
        totalCandidats: candidatsResult[0].totalCandidats,
        totalVotes: votesResult[0].totalVotes || 0,
      });
    });
  });
});

//====================================
// Fonction pour enregistrer le vote du candidat
//=====================================
async function enregistrerVoteCandidat(candidatId, ip) {
  await db.query("UPDATE candidats SET votes = votes + 1 WHERE id = ?", [
    candidatId,
  ]);
  await db.query(
    "INSERT INTO votes_ip_candidats (candidat_id, ip) VALUES (?, ?)",
    [candidatId, ip],
  );
}

//=========================================
// Fonction pour enregistrer le vote du secteur
//=========================================
async function enregistrerVoteSecteur(secteurId, reponse, ip) {
  const champ = reponse === "oui" ? "votes_oui" : "votes_non";

  // Incrémenter le vote dans la bonne colonne
  const result = await db.query(
    `UPDATE secteurs SET ${champ} = ${champ} + 1 WHERE id = ?`,
    [secteurId],
  );
  console.log(`Votes après mise à jour pour secteur ${secteurId}:`, result);

  if (result.affectedRows === 0) {
    console.log(
      `Erreur d'incrémentation des votes pour le secteur avec l'ID ${secteurId}`,
    );
  }

  // Insérer l'IP pour empêcher les votes multiples
  await db.query("INSERT INTO votes_ip (secteur_id, ip) VALUES (?, ?)", [
    secteurId,
    ip,
  ]);
  console.log(`Vote enregistré pour le secteur ${secteurId} avec l'IP ${ip}`);
}

//======================================
// verification de vote utiisateur
//=======================================
const vote = async (req, res) => {
  try {
    const secteurId = parseInt(req.params.id);
    const vote = req.body.vote;
    const userId = req.session.userId || 1;

    if (!secteurId || !vote) {
      return res.status(400).send("Paramètres manquants ou invalides");
    }

    // Vérifier si l'utilisateur a déjà voté
    const checkVoteSql =
      "SELECT * FROM votes_utilisateur WHERE user_id = ? AND secteur_id = ?";
    const [checkVoteResult] = await db
      .promise()
      .query(checkVoteSql, [userId, secteurId]);

    if (checkVoteResult.length > 0) {
      return res.status(400).send("Vous avez déjà voté pour ce secteur");
    }

    // Insertion du vote
    const insertVoteSql =
      "INSERT INTO votes_utilisateur (user_id, secteur_id, vote) VALUES (?, ?, ?)";
    await db.promise().query(insertVoteSql, [userId, secteurId, vote]);

    // Mise à jour des votes dans la table secteur
    const column = vote === "oui" ? "oui" : "non";
    const updateSql = `UPDATE secteurs SET ${column} = ${column} + 1 WHERE id = ?`;
    await db.promise().query(updateSql, [secteurId]);

    return res.json({ success: true, message: "Vote enregistré avec succès" });
  } catch (err) {
    console.error("🔴 Erreur:", err);
    return res.status(500).send("Erreur serveur");
  }
};

//=================================
//controle de vote par ip
//====================================
async function enregistrerVote(secteurId, vote, ip) {
  if (vote === "oui") {
    await db.query(
      "UPDATE secteurs SET votes_oui = votes_oui + 1 WHERE id = ?",
      [secteurId],
    );
  } else if (vote === "non") {
    await db.query(
      "UPDATE secteurs SET votes_non = votes_non + 1 WHERE id = ?",
      [secteurId],
    );
  }
  await db.query("INSERT INTO votes_ip (secteur_id, ip) VALUES (?, ?)", [
    secteurId,
    ip,
  ]);
}



app.get("/session-test", (req, res) => {
  console.log("Test de session =>", req.session);
  res.json({ session: req.session });
});


//========================================
// Lancer le serveur
//=======================================

// Démarrage du serveur
app.listen(port, () => {
  console.log(`✅ Serveur démarré sur http://0.0.0.0:${port}`);
});






