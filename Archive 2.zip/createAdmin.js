const readline = require('readline');
const bcrypt = require('bcrypt');
const db = require('../config/db'); // Adapter selon le chemin exact
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

function ask(question) {
  return new Promise(resolve => rl.question(question, resolve));
}

async function createAdmin() {
  try {
    const username = await ask("Nom d'utilisateur : ");
    const password = await ask("Mot de passe : ");
    rl.close();

    const hashedPassword = await bcrypt.hash(password, 10);

    await db.query(
      'INSERT INTO admins (username, password) VALUES (?, ?)',
      [username, hashedPassword]
    );

    console.log("✅ Administrateur créé avec succès !");
  } catch (error) {
    console.error("❌ Erreur lors de la création de l'administrateur :", error);
    rl.close();
  }
}

createAdmin();


